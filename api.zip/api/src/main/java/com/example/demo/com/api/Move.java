package com.api

@JsonInclude(JsonInclude.Include.NON_NULL)
public class InputReq {

    @JsonProperty("f")
    Private Integer f;
    @JsonProperty("b")
    Private Integer b;
    @JsonProperty("r")
    Private Integer r;
    @JsonProperty("l")
    Private Integer l;
    @JsonProperty("o")
    Private Integer o;
    
    
    public Integer getF(){
        return f;
    }
    public void setF(Integer f){
         this.f = f;
    }

    public Integer getB(){
        return b;
    }
    public void setB(Integer b){
        this.b = b;
    }
    public Integer getR(){
        return r;
    }
    public void setR(Integer r){
        this.r = r;
    }
    public Integer getL(){
        return l;
    }
    public void setL(Integer l){
        this.l = l;
    }
    public Integer getO(){
        return o;
    }
    public void setO(Integer o){
        this.o = o;
    }
    
    

}
