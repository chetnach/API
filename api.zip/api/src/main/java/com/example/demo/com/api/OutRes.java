package com.api

@JsonInclude(JsonInclude.Include.NON_NULL)
public class OutRes {
    
    @JsonProperty("position")
    Private PositionOut position;
    
    
    public PositionOut getPosition(){
        return position;
    }
    public void setPosition(PositionOut Position){
        this.position = position;
    }
    
    

}
