package com.api

@JsonInclude(JsonInclude.Include.NON_NULL)
public class InputReq {

    @JsonProperty("position")
    Private Position position;
    
    
    @JsonProperty("move")
    Private List<Move> move = null;
    
    public Position getPosition(){
        return position;
    }
    public void setPosition(Position Position){
         this.position = position;
    }
    
    public List<Move> getMove(){
        return move;
    }
    public void setMove(move<Move> move){
        this.move = position;
    }
    

}
