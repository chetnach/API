package com.example.demo;

import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

@ComponentScan
@ApplicationPath("/api")
public class JaxRsApplication extends Application {

	

}
