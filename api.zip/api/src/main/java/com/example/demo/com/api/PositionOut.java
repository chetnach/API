package com.api

@JsonInclude(JsonInclude.Include.NON_NULL)
public class PositionOut {
    
    @JsonProperty("position")
    Private String position;
    
    @JsonProperty("x")
    Private Integer x;
    @JsonProperty("y")
    Private Integer y;
    
    
    public PositionOut getPosition(){
        return position;
    }
    public void setPosition(PositionOut Position){
        this.position = position;
    }
    
    public Integer getX(){
        return x;
    }
    public void setX(Integer x){
        this.x = x;
    }
    
    public Integer getY(){
        return y;
    }
    public void setY(Integer y){
        this.y = y;
    }

}
