package com.api

@Service
@Path("/")
@PRODUCES(MediaType.APPLICATION_JSON)
@CONSUMES(MediaType.APPLICATION_JSON)
public class RoverApi {

	@Autowired
    private RoverImpl roverImpl;
    
    
    @POST
    @Path("/v1/rover")
    public OutRes retriveStatus(InputReq request)
    {
        OutRes outRes= new OutRes();
        try{
            return roverImpl.retrieve(request);
        }
        catch(Exception e){
            return outRes;
        }
    }

}
