package com.example.demo;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class InputReq {

    @JsonProperty("position")
    private Position position;
    
    
    @JsonProperty("move")
    private List<Move> move = null;


	public Position getPosition() {
		return position;
	}


	public void setPosition(Position position) {
		this.position = position;
	}


	public List<Move> getMove() {
		return move;
	}


	public void setMove(List<Move> move) {
		this.move = move;
	}
    

    

}
