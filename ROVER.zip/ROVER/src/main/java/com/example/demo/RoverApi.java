package com.example.demo;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@Service
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@RestController
@Path("/")
public class RoverApi {

	@Autowired
    private RoverImpl roverImpl;
    
    
//	@RequestMapping(value="/v1/rover",method=RequestMethod.POST)
	
	@POST
	@Path("/v1/rover")
    public OutRes retriveStatus(InputReq request)
    {
        OutRes outRes= new OutRes();
        try{
            return roverImpl.retrive(request);
        }
        catch(Exception e){
            return outRes;
        }
    }

}
