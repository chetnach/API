package com.example.demo;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class OutRes {
    
    @JsonProperty("position")
    private PositionOut position;

	public PositionOut getPosition() {
		return position;
	}

	public void setPosition(PositionOut position) {
		this.position = position;
	}
    
    
  
    
    

}
