package com.example.demo;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class Move {

    @JsonProperty("f")
    private Integer f=0;
    @JsonProperty("b")
    private Integer b=0;
    @JsonProperty("r")
    private Integer r=0;
    @JsonProperty("l")
    private Integer l=0;
    @JsonProperty("o")
    private String o="";
    
    
    public Integer getF(){
        return f;
    }
    public void setF(Integer f){
         this.f = f;
    }

    public Integer getB(){
        return b;
    }
    public void setB(Integer b){
        this.b = b;
    }
    public Integer getR(){
        return r;
    }
    public void setR(Integer r){
        this.r = r;
    }
    public Integer getL(){
        return l;
    }
    public void setL(Integer l){
        this.l = l;
    }
    public String getO(){
        return o;
    }
    public void setO(String o){
        this.o = o;
    }
    
    

}
