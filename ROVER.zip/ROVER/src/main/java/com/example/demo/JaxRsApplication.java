package com.example.demo;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

import org.springframework.context.annotation.ComponentScan;

@ComponentScan
@ApplicationPath("/api")
public class JaxRsApplication extends Application {

	

}
