package com.example.demo;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class PositionOut {
    
    @JsonProperty("direction")
    private  String direction;
    
    @JsonProperty("x")
    private Integer x;
    @JsonProperty("y")
    private Integer y;
    
  
    
    public String getDirection() {
		return direction;
	}
	public void setDirection(String direction) {
		this.direction = direction;
	}
	public Integer getX(){
        return x;
    }
    public void setX(Integer x){
        this.x = x;
    }
    
    public Integer getY(){
        return y;
    }
    public void setY(Integer y){
        this.y = y;
    }

}
