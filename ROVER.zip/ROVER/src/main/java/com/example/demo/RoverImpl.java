package com.example.demo;

import org.springframework.stereotype.Service;

@Service
public class RoverImpl {
    String pos;
    String dire;
    Integer x;
    Integer y;

    public OutRes retrive(InputReq req)
    {
        OutRes outRes= new OutRes();
        PositionOut position = new PositionOut();
        dire = req.getPosition().getDirection();
        x = req.getPosition().getX();
        y = req.getPosition().getY();
        
        for(Move n : req.getMove()){
            String o =  n.getO();
            Integer l = n.getL();
             Integer f = n.getF();
             Integer r = n.getR();
             Integer b = n.getB();
            
            if(dire.equals("N")){
                if(r==90)
                    dire="E";
                else if(r==180)
                    dire="S";
                else if(r==270)
                    dire="W";
                else if(l==90)
                    dire="W";
                else if(l==180)
                    dire="S";
                else if(l==270)
                    dire="E";
                else dire = "N";
                
            }
            
            if(dire.equals("E")){
                if(r==90)
                    dire="S";
                else if(r==180)
                    dire="W";
                else if(r==270)
                    dire="N";
                else if(l==90)
                    dire="N";
                else if(l==180)
                    dire="W";
                else if(l==270)
                    dire="S";
                else dire = "E";
                
            }
            
            if(dire.equals("W")){
                if(r==90)
                    dire="N";
                else if(r==180)
                    dire="E";
                else if(r==270)
                    dire="S";
                else if(l==90)
                    dire="S";
                else if(l==180)
                    dire="E";
                else if(l==270)
                    dire="N";
                else dire = "W";
                
            }
            
            if(dire.equals("S")){
                if(r==90)
                    dire="W";
                else if(r==180)
                    dire="N";
                else if(r==270)
                    dire="E";
                else if(l==90)
                    dire="E";
                else if(l==180)
                    dire="N";
                else if(l==270)
                    dire="W";
                else dire = "S";
                
            }
            
            x=x+f;
            y=y-b;
}
        position.setDirection(dire);
        position.setX(x);
        position.setY(y);
        outRes.setPosition(position);
        return outRes;
        
    }

}
